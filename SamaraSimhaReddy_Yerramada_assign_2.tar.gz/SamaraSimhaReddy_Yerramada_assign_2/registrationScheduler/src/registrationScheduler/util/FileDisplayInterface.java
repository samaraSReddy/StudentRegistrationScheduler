package registrationScheduler.util;

public interface FileDisplayInterface {
	/**
	 * @return nothing
	 */
	public void writeScheduleToFile();
	
	} 