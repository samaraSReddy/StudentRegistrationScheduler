
package registrationScheduler.util;

public interface StdoutDisplayInterface {
   /**
    * @return nothing
    */
	public void writeScheduleToScreen();
	
} 


