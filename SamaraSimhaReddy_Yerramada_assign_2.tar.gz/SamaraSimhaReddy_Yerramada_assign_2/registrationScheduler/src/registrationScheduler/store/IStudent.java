package registrationScheduler.store;

import java.util.Vector;

/**
 *Student Interface 
 * @author samara
 *
 */
public interface IStudent {

	public String getStudentName();

	public Vector<String> getRequestedListofCourses();

	public Vector<String> getAllocatedCourses();

	public int getPreferenceScore();

	public Vector<String> getAddedCourses();

	public Vector<String> getDroppedCourses();

	public void setStudentName(String studentName);

	public void setRequestedListofCourses(Vector<String> requestedListofCourses);

	public void setAllocatedCourses(Vector<String> allocatedCourses);

	public void setPreferenceScore(int preferenceScore);


	public void setAddedCourses(Vector<String> addedCourses);

	public void setDroppedCourses(Vector<String> droppedCourses);

	public String printResultString();	
	

}
